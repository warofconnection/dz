from pathlib import Path
import sys, re, html, hashlib, json, shutil
from lxml import etree as E

W = Path('/workspace/work')
sys.path.insert(0, str(W/'repo/tools'))
from pkt_document_codec import decode_document, encode_document

source = next(Path('/workspace/attachments/bf955fde-fd59-444b-9676-5817f110598f').glob('*.pkt'))
raw = source.read_bytes()
xml = decode_document(raw)
root = E.fromstring(xml)
devices = {d.findtext('ENGINE/NAME'): d for d in root.findall('NETWORK/DEVICES/DEVICE')}
page = (W/'hw2_support/index.html').read_text()
oldpages = [f.findtext('FILE_CONTENT/TEXT') for f in devices['SRV-MIS'].findall('ENGINE/.//FILE')
            if f.findtext('NAME') in ('http:', 'index.html') and f.find('FILE_CONTENT/TEXT') is not None]
assert len(oldpages) == 2 and oldpages[0] == oldpages[1]

# Replace only the two page text payloads inside SRV-MIS; every other XML byte stays intact.
count = 0
def replace_device(match):
    global count
    block = match.group()
    if E.fromstring(block).findtext('ENGINE/NAME') != 'SRV-MIS':
        return block
    def replace_text(m):
        global count
        if html.unescape(m.group(1).decode()) == oldpages[0]:
            count += 1
            return b'<TEXT>' + html.escape(page, quote=False).encode() + b'</TEXT>'
        return m.group()
    return re.sub(rb'<TEXT>(.*?)</TEXT>', replace_text, block, flags=re.S)
newxml = re.sub(rb'<DEVICE(?:\s[^>]*)?>.*?</DEVICE>', replace_device, xml, flags=re.S)
assert count == 2
newroot = E.fromstring(newxml)
newdevices = {d.findtext('ENGINE/NAME'): d for d in newroot.findall('NETWORK/DEVICES/DEVICE')}
for tree in (root, newroot):
    mis = next(d for d in tree.findall('NETWORK/DEVICES/DEVICE') if d.findtext('ENGINE/NAME') == 'SRV-MIS')
    for f in mis.findall('ENGINE/.//FILE'):
        if f.findtext('NAME') in ('http:', 'index.html') and f.find('FILE_CONTENT/TEXT') is not None:
            f.find('FILE_CONTENT/TEXT').text = 'PAGE_PAYLOAD'
assert E.tostring(root) == E.tostring(newroot), 'Unexpected changes outside website'
mail_counts = {name:int(d.findtext('ENGINE/EMAIL_CLIENT/NO_OF_MAILS', '0')) for name,d in devices.items()}
assert mail_counts['C1-PC01'] == mail_counts['C2-PC17'] == 1
for name in devices:
    for path in ('ENGINE/EMAIL_CLIENT', 'ENGINE/EMAIL_SERVER'):
        old,new = devices[name].find(path),newdevices[name].find(path)
        if old is not None:
            assert E.tostring(old) == E.tostring(new)
out = encode_document(newxml)
assert decode_document(out) == newxml
backup = W/'backups';backup.mkdir(exist_ok=True)
target = next((W/'deliverables').glob('*.pkt'))
if not (backup/'generated-before-site-update.pkt').exists():
    shutil.copy2(target, backup/'generated-before-site-update.pkt')
shutil.copy2(source, backup/'user-tested-before-site-update.pkt')
target.write_bytes(out)
sha = lambda b: hashlib.sha256(b).hexdigest()
audit = dict(source=source.name, source_sha256=sha(raw), output_sha256=sha(out),
             version='8.2.2.0400', devices=120, links=109,
             changed_payloads=['SRV-MIS/http:/TEXT','SRV-MIS/index.html/TEXT'],
             other_xml_bytes_unchanged=True, all_email_state_unchanged=True,
             stored_received_emails={k:v for k,v in mail_counts.items() if v},
             runtime_after_update='PENDING_USER_REOPEN_AND_HTTP_CHECK')
(W/'hw2_support/site-update-audit.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2))
print(json.dumps(audit,ensure_ascii=False,indent=2))
