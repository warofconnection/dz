from pathlib import Path
from lxml import etree as E
import sys,json,uuid,hashlib,copy
W=Path('/workspace/work');sys.path.insert(0,str(W/'repo/tools'))
from pkt_document_codec import decode_document,encode_document
p=next((W/'deliverables').glob('*.pkt'));raw=p.read_bytes();xml=decode_document(raw);r=E.fromstring(xml);before=copy.deepcopy(r)
D=json.loads((W/'hw2_support/project.json').read_text());by={d.findtext('ENGINE/NAME'):d for d in r.findall('NETWORK/DEVICES/DEVICE')}
notes=r.find('PHYSICALWORKSPACE/NOTES');assert notes is not None
for c in list(notes):notes.remove(c)
labels={}
def add(key,x,y,text):
 n=E.SubElement(notes,'NOTE',uuid='{'+str(uuid.uuid5(uuid.NAMESPACE_URL,'clinic8-logical-label-'+key))+'}')
 for tag,value in [('X',x),('Y',y),('Z',40000+len(notes)),('TEXT',text),('NOTECLUSTERID','1-1'),('MEM_ADDR',930000000+len(notes))]:
  e=E.SubElement(n,tag);e.text=str(value)
  if tag=='TEXT':e.set('translate','true')
 labels[key]=text
for name,e in D['endpoints'].items():
 d=by[name];x=float(d.findtext('WORKSPACE/LOGICAL/X'));y=float(d.findtext('WORKSPACE/LOGICAL/Y'))
 addr=e['ip']+'/'+e['subnet'].split('/')[1] if e['ip'] else 'DHCP | VLAN '+str(e['vlan'])
 if '-PC' in name:text=e['department']+'\n'+e['role']+'\n'+addr
 elif name.startswith('SRV-'):
  text={'SRV-MIS':'Сайт поликлиники (HTTP)','SRV-MAIL':'DNS и почтовый сервер\nSMTP / POP3','SRV-FILE':'Диагностический архив\nФайловый сервер'}[name]+'\n'+addr
 elif name.startswith('SW-'):text='Коммутатор | управление\n'+addr
 elif '-PR' in name:text='Сетевое МФУ\n'+addr
 else:text='Гостевой планшет\n'+addr
 add(name,x-45,y+45,text)
for site,x,y in [('C1',40,100),('C2',40,1550),('B1',1800,100),('B2',1800,1550)]:
 add('area-'+site,x+20,y+15,{'C1':'ЦЕНТРАЛЬНЫЙ КОРПУС — ЭТАЖ 1','C2':'ЦЕНТРАЛЬНЫЙ КОРПУС — ЭТАЖ 2','B1':'ФИЛИАЛ 1 — АВТОНОМНЫЙ','B2':'ФИЛИАЛ 2 — АВТОНОМНЫЙ'}[site])
 name='R-'+site;d=by[name];rx=float(d.findtext('WORKSPACE/LOGICAL/X'));ry=float(d.findtext('WORKSPACE/LOGICAL/Y'))
 text='Маршрутизатор / DHCP\nШлюзы VLAN: адрес .1'
 if site.startswith('C'):text+='\nGi0/1: 10.59.250.'+('1' if site=='C1' else '2')+'/30'
 else:text+='\nСвязь с центром отсутствует'
 add(name,rx-45,ry+45,text)
 name=site+'-AP1';d=by[name];ax=float(d.findtext('WORKSPACE/LOGICAL/X'));ay=float(d.findtext('WORKSPACE/LOGICAL/Y'))
 add(name,ax-45,ay-80,'Точка доступа Wi-Fi\nClinic8-'+site+'-Guest\nWPA2-PSK / AES | VLAN 90')
for name in ['R-EDGE','R-ISP','SW-PROVIDER','PUBLIC-WEB']:
 d=by[name];x=float(d.findtext('WORKSPACE/LOGICAL/X'));y=float(d.findtext('WORKSPACE/LOGICAL/Y'))
 add(name,x-45,y+45,'Резерв ДЗ1 | выключено\nВне действующей сети')
add('title',40,30,'ДЗ2 | Городская поликлиника № 8 | ИУ10-59 | 10.59.0.0/16 | Администрация: 10.59.8.0/28')
add('reserve',40,3080,'ОПЕРАТОРСКИЙ СЕГМЕНТ — ВЫКЛЮЧЕННЫЙ РЕЗЕРВ ДЗ1')
# The direct NOTES child is the logical drawing layer. Nested ENVIRONMENT/NOTES is not.
for name,e in D['endpoints'].items():
 assert name in labels
 if '-PC' in name:assert e['role'] in labels[name] and e['department'] in labels[name]
 if e['ip']:assert e['ip']+'/'+e['subnet'].split('/')[1] in labels[name]
newxml=E.tostring(r,encoding='utf-8');check=copy.deepcopy(r)
check.find('PHYSICALWORKSPACE').replace(check.find('PHYSICALWORKSPACE/NOTES'),copy.deepcopy(before.find('PHYSICALWORKSPACE/NOTES')))
assert E.tostring(check)==E.tostring(before),'Changes outside logical notes'
packed=encode_document(newxml);assert decode_document(packed)==newxml
backup=W/'backups/before-logical-labels.pkt'
if not backup.exists():backup.write_bytes(raw)
p.write_bytes(packed)
sha=lambda b:hashlib.sha256(b).hexdigest()
audit={'source_sha256':sha(raw),'output_sha256':sha(packed),'changed_path':'PHYSICALWORKSPACE/NOTES','notes':len(notes),'pc_role_labels':84,'static_endpoint_labels':41,'server_function_labels':3,'other_document_content_unchanged':True,'network_configuration_unchanged':True,'email_state_unchanged':True,'device_positions_unchanged':True,'runtime_opening':'PENDING'}
(W/'hw2_support/labels-audit.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2))
print(json.dumps(audit,ensure_ascii=False,indent=2))
