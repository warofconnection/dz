from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import shutil, json, hashlib
import fitz
from docx import Document

w=Path('/workspace/work');s=w/'hw2_support';o=w/'deliverables';g=w/'github-upload/deliverables/dz2'
doc=next(o.glob('*.docx'));pkt=next(o.glob('*.pkt'))
pdf=w/'report_preview/Устинов ИУ10-59 ДЗ2 — для проверки.pdf'
selection=json.loads((s/'report-selection.json').read_text())
images=[w/'evidence'/x['file'] for x in selection['figures']]
originals=sorted((w/'evidence').glob('*.png'))
with ZipFile(doc) as z:
 hashes={hashlib.sha256(z.read(n)).hexdigest() for n in z.namelist() if n.startswith('word/media/')}
 assert hashes=={hashlib.sha256(p.read_bytes()).hexdigest() for p in images}
pages=fitz.open(pdf);screenshot_pages=[]
for i,p in enumerate(pages):
 if p.get_image_info():screenshot_pages.append(i+1)
 for block in p.get_text('blocks'):
  assert block[0]>=35 and block[2]<=575 and block[1]>=20 and block[3]<=824,(i+1,block[:4])
assert sum(len(p.get_image_info()) for p in pages)==len(images)
text='\n'.join(p.get_text() for p in pages)
for banned in ['Доказательства','Источник:','Источники','Состав комплекта','9. Проверки','пользователь сообщил','Рабочая версия','S01','T01']:
 assert banned not in text,banned
assert 'Вывод' in text and len(images)==10
assert len([p for p in Document(doc).paragraphs if p.text.startswith('Рисунок ')])==10
for name in ['build_report.py','package_review.py']:shutil.copy2(w/name,s/name)
shutil.copy2(pdf,s/'report-preview.pdf');shutil.copytree(w/'evidence',s/'screenshots',dirs_exist_ok=True)
p=s/'live-checks.json';live=json.loads(p.read_text());live['report_evidence'].update(images_embedded=len(images),original_images_retained=len(originals),screenshot_pages=screenshot_pages,selected_files=[x.name for x in images]);p.write_text(json.dumps(live,ensure_ascii=False,indent=2))
p=s/'verification.json';v=json.loads(p.read_text());v['screenshots']=f'{len(images)}_EXAMPLES_EMBEDDED_{len(originals)}_ORIGINALS_RETAINED';p.write_text(json.dumps(v,ensure_ascii=False,indent=2))
(s/'README.txt').write_text(f'''ДЗ2 — Устинов И. М., ИУ10-59, вариант 8.

Отчёт переписан от первого лица: {len(pages)} страниц, {len(images)} примеров со скриншотами.
Однотипные устройства объединены в диапазоны. Все 26 подсетей отражены в плане.
Раздел 9, источники, состав комплекта, таблицы приёмки и полные конфигурации
из отчёта удалены по просьбе автора. Все исходные снимки сохранены здесь: {len(originals)} шт.

configs/ и CSV — полные конфигурации и адресные ведомости;
index.html — обновлённый сайт, встроенный в PKT;
project.json — параметры проекта;
site-update-audit.json — проверка сохранности конфигураций и писем при обновлении сайта;
live-checks.json, verification.json — подробные технические результаты проверок;
report-selection.json — выбранные примеры для сокращённого отчёта;
screenshots/ — все исходные снимки;
report-preview.pdf — PDF для просмотра отчёта;
*.py — рабочие скрипты подготовки.

В отчёте старый снимок сайта заменён новым примером с C2-PC17.
Обновлённая страница также открывается на Tablet PC0. В PKT и index.html
удалена нижняя подпись; сетевые настройки и два полученных письма сохранены.
Проверки на выбранных узлах не означают отдельного тестирования каждого ПК
и каждой учётной записи. Основной архив содержит только DOCX и PKT.
''')
audit=json.loads((s/'site-update-audit.json').read_text())
assert hashlib.sha256(pkt.read_bytes()).hexdigest()==audit['output_sha256']
assert audit['other_xml_bytes_unchanged'] and audit['all_email_state_unchanged']
shutil.copy2(pkt,g/'Ustinov_IU10-59_DZ2_review.pkt')
with ZipFile(o/'DZ2_Ustinov_IU10-59_review.zip','w',ZIP_DEFLATED) as z:
 for f in [doc,pkt]:z.write(f,f.name)
with ZipFile(o/'DZ2_support.zip','w',ZIP_DEFLATED) as z:
 for f in sorted(s.rglob('*')):
  if f.is_file():z.write(f,str(f.relative_to(s)))
for n in ['DZ2_Ustinov_IU10-59_review.zip','DZ2_support.zip']:
 with ZipFile(o/n) as z:assert z.testzip() is None
 shutil.copy2(o/n,g/n)
shutil.copy2(doc,g/'Ustinov_IU10-59_DZ2_report.docx')
(g/'README.md').write_text(f'''# ДЗ2 — Устинов И. М., ИУ10-59, вариант 8

- [Отчёт Word отдельно](Ustinov_IU10-59_DZ2_report.docx)
- [Архив: отчёт Word и модель Cisco](DZ2_Ustinov_IU10-59_review.zip)
- [Модель Cisco отдельно](Ustinov_IU10-59_DZ2_review.pkt)
- [Дополнительные материалы: все снимки, конфигурации, PDF](DZ2_support.zip)

Для скачивания откройте файл и нажмите **Download raw file**.

Отчёт переписан от лица студента: **{len(pages)} страниц и {len(images)} примеров со скриншотами**.
Убраны раздел 9, источники, состав комплекта и служебные таблицы проверок.
Однотипные ПК объединены в диапазоны; все 26 подсетей сохранены в адресном плане.
В дополнительных материалах сохранены все исходные снимки: {len(originals)} шт.

В отчёте показан актуальный дизайн сайта на C2-PC17. В архиве скриншотов
также сохранён новый пример открытия сайта на Tablet PC0 по Wi-Fi.
В PKT удалена нижняя подпись сайта; сетевые настройки и оба тестовых письма
сохранены без изменения. Версия файла — Cisco Packet Tracer 8.2.2.0400.

Второй октет — 59; администрация — 10.59.8.0/28. Центр и оба филиала автономны.
Основные сценарии проверены на выбранных узлах; отдельная проверка каждого ПК
и всех почтовых учётных записей не заявляется.
''')
print(f'Packaged: {len(pages)} pages, {len(images)} example screenshots, {len(originals)} original screenshots retained. PKT website footer removed; network and email state preserved.')
