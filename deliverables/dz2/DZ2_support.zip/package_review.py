from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
import shutil,json,hashlib
import fitz

w=Path('/workspace/work');s=w/'hw2_support';o=w/'deliverables';g=w/'github-upload/deliverables/dz2'
doc=next(o.glob('*.docx'));pkt=next(o.glob('*.pkt'))
pdf=w/'report_preview/Устинов ИУ10-59 ДЗ2 — для проверки.pdf'
images=sorted((w/'evidence').glob('*.png'))
with ZipFile(doc) as z:
 hashes={hashlib.sha256(z.read(n)).hexdigest() for n in z.namelist() if n.startswith('word/media/')}
 assert all(hashlib.sha256(p.read_bytes()).hexdigest() in hashes for p in images)
pages=fitz.open(pdf);screenshot_pages=[]
for i,p in enumerate(pages):
 if 'Источник: скриншот пользователя' in p.get_text():
  assert p.get_images();screenshot_pages.append(i+1)
 for block in p.get_text('blocks'):
  assert block[0]>=35 and block[2]<=575 and block[1]>=20 and block[3]<=824,(i+1,block[:4])
assert len(screenshot_pages)==len(images)
for name in ['build_report.py','package_review.py']:shutil.copy2(w/name,s/name)
shutil.copy2(pdf,s/'report-preview.pdf');shutil.copytree(w/'evidence',s/'screenshots',dirs_exist_ok=True)
p=s/'live-checks.json';live=json.loads(p.read_text());live['report_evidence'].update(images_embedded=len(images),screenshot_pages=screenshot_pages,source_archives=['скрины.zip']+['скрины'+str(i)+'.zip' for i in range(2,len(list((w/'evidence').glob('source-index*.json')))+1)]);p.write_text(json.dumps(live,ensure_ascii=False,indent=2))
p=s/'verification.json';v=json.loads(p.read_text());v['screenshots']=f'{len(images)}_ORIGINAL_IMAGES_EMBEDDED';v['routing_tables']='PASS_ALL_FOUR_ROUTERS_USER_SCREENSHOTS';p.write_text(json.dumps(v,ensure_ascii=False,indent=2))
(s/'README.txt').write_text(f'''ДЗ2 — Устинов И. М., ИУ10-59, вариант 8.

Статус: частично проверено пользователем в Cisco. В отчёте {len(pages)} страниц,
включены {len(images)} подлинных скриншотов. Работа ещё не готова к окончательной сдаче.
Версия исходного PKT: 8.2.2.0400. Параметры: второй октет 59,
администрация 10.59.8.0/28, автономные филиалы, без нулевого маршрута.

Основной ZIP содержит ровно два файла: DOCX и PKT.
В дополнительном ZIP находятся:
configs/ — полные конфигурации 4 маршрутизаторов и 6 коммутаторов;
subnets.csv, endpoints.csv, ports.csv, email.csv — расчёты и ведомости;
index.html — обновлённая страница поликлиники, уже встроена в текущий PKT;
site-update-audit.json — происхождение текущего PKT и проверка сохранности настроек/почты;
project.json — исходные проектные данные;
verification.json — сводка проверок;
live-checks.json — фактические результаты пользовательских проверок;
screenshots/ — все исходные снимки и соответствие исходным именам;
report-preview.pdf — контрольный PDF отчёта;
topology.png — расчётная схема, не скриншот Cisco;
*.py — использованные генераторы и проверки из рабочей среды.

Статусы и ограничения изложены в отчёте. Частичные проверки не означают
проверку всех узлов/учётных записей. Первые потерянные пакеты отражены честно.
Модель открывать через File → Open; Script Modules не запускать.
Архив опубликован в GitHub по просьбе пользователя; преподавателю не отправлялся.
''')
with ZipFile(o/'DZ2_Ustinov_IU10-59_review.zip','w',ZIP_DEFLATED) as z:
 for f in [doc,pkt]:z.write(f,f.name)
with ZipFile(o/'DZ2_support.zip','w',ZIP_DEFLATED) as z:
 for f in sorted(s.rglob('*')):
  if f.is_file():z.write(f,str(f.relative_to(s)))
for n in ['DZ2_Ustinov_IU10-59_review.zip','DZ2_support.zip']:
 with ZipFile(o/n) as z:assert z.testzip() is None
 shutil.copy2(o/n,g/n)
shutil.copy2(doc,g/'Ustinov_IU10-59_DZ2_report.docx')
audit=json.loads((s/'site-update-audit.json').read_text())
assert hashlib.sha256(pkt.read_bytes()).hexdigest()==audit['output_sha256']
assert audit['other_xml_bytes_unchanged'] and audit['all_email_state_unchanged']
shutil.copy2(pkt,g/'Ustinov_IU10-59_DZ2_review.pkt')
(g/'README.md').write_text(f'''# ДЗ2 — Устинов И. М., ИУ10-59, вариант 8

**Версия для проверки, не окончательный комплект сдачи.**

- [Основной архив: отчёт Word и модель Cisco](DZ2_Ustinov_IU10-59_review.zip)
- [Модель Cisco отдельно](Ustinov_IU10-59_DZ2_review.pkt)
- [Отчёт Word отдельно](Ustinov_IU10-59_DZ2_report.docx)
- [Дополнительные материалы: скриншоты, конфигурации, PDF](DZ2_support.zip)

Для скачивания откройте файл и нажмите **Download raw file**.
Версия исходного файла: **Cisco Packet Tracer 8.2.2.0400**.

Основа — финальный PKT пользователя из ДЗ1. Второй октет — 59;
администрация — 10.59.8.0/28. Центр и оба филиала изолированы.

Отчёт: **{len(pages)} стр.**, **{len(images)} подлинных скриншота пользователя**.
Подтверждены выбранные проверки DHCP, связи между этажами и отделами филиалов,
DNS/HTTP, почта reg1 ↔ admin1 и связь всех четырёх Wi-Fi-клиентов со своими шлюзами.
Сайт открыт по имени на C2-PC17 и планшетах обоих этажей центра. Проверены таблицы маршрутов
всех четырёх маршрутизаторов: нулевых маршрутов нет. Внешние интерфейсы
филиалов выключены, локальные подинтерфейсы up/up. На SW-C1B и SW-C2B
проверены VLAN, назначения access-портов и действующие trunk Gi0/1.

Другие проверки ещё не завершены; точный статус указан в отчёте и live-checks.json
в дополнительных материалах. Текущий PKT основан на сохранённом пользователем
файле «Устинов ИУ10-59 ДЗ2 проверка.pkt». Обновлена только страница поликлиники:
зелёная шапка, направления помощи, часы работы и памятка перед приёмом.
Конфигурации и оба полученных тестовых письма сохранены без изменения.
Новая модель прошла проверку структуры и целостности; повторное открытие в Cisco
и отображение обновлённой страницы ещё должен проверить пользователь.
Скриншоты сайта в отчёте пока показывают прежний дизайн и подписаны соответственно.
Оригиналы всех снимков сохранены в дополнительном ZIP.

Не запускать Script Modules; открыть PKT через File → Open.
''')
print(f'Verified and packaged: {len(images)} screenshots, {len(pages)} report pages; audited website update.')
