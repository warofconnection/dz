from pathlib import Path
import sys,re,json,copy,ipaddress,math,csv,hashlib,uuid
from lxml import etree as E
sys.path.insert(0,str(Path('/workspace/work/repo/tools')))
from pkt_document_codec import decode_document,encode_document

W=Path('/workspace/work'); OUT=W/'deliverables'
OUT.mkdir(parents=True,exist_ok=True)
SUP=W/'hw2_support';(SUP/'configs').mkdir(parents=True,exist_ok=True)
SRC=W/'hw1/Устинов ИУ10-59.pkt'
raw=SRC.read_bytes();xml=decode_document(raw)
parser=E.XMLParser(strip_cdata=False,remove_blank_text=False)
root=E.fromstring(xml,parser);original=E.fromstring(xml,parser)
devices=root.findall('NETWORK/DEVICES/DEVICE');by={d.findtext('ENGINE/NAME'):d for d in devices}
old=E.parse(str(W/'old_config.xml'));oldby={d.findtext('ENGINE/NAME'):d for d in old.findall('NETWORK/DEVICES/DEVICE')}
PASS='Clinic8Lab2026';DNS='10.59.20.3'

def put(p,tag,val):
 n=p.find(tag)
 if n is None:n=E.SubElement(p,tag)
 n.text=str(val)
 return n
def clear(n):
 for c in list(n):n.remove(c)
 n.text=None
def subnet(site,vid,octet,prefix,title,pcs=0,mode='static',infra=1):
 n=ipaddress.ip_network(f'10.59.{octet}.0/{prefix}')
 s=dict(site=site,vlan=vid,octet=octet,prefix=prefix,title=title,pcs=pcs,mode=mode,infra=infra,
        network=str(n.network_address),cidr=str(n),mask=str(n.netmask),broadcast=str(n.broadcast_address),
        first=str(n.network_address+1),last=str(n.broadcast_address-1),capacity=n.num_addresses-2,
        gateway=str(n.network_address+1),reserve=math.ceil(pcs*.2))
 s['required']=pcs+s['reserve']+infra
 assert s['capacity']>=s['required']
 nets.append(s);return s
nets=[]
REG=subnet('C1',10,1,28,'Регистратура',8,'DHCP')
TER=subnet('C1',20,2,28,'Терапия',8,'DHCP')
DIA=subnet('C1',30,3,28,'Диагностика',8)
SPEC=subnet('C2',40,4,27,'Врачи-специалисты',16,'DHCP')
ADM=subnet('C2',8,8,28,'Администрация',6)
IT=subnet('C2',60,6,29,'ИТ',2)
SERV=subnet('C1',50,20,29,'Серверы',3)
PR1=subnet('C1',70,30,29,'Печать C1',2)
PR2=subnet('C2',70,31,29,'Печать C2',2)
G1=subnet('C1',90,90,28,'Wi-Fi C1',10,'DHCP')
G2=subnet('C2',90,91,28,'Wi-Fi C2',10,'DHCP')
M1=subnet('C1',99,98,29,'Управление C1',2)
M2=subnet('C2',99,99,29,'Управление C2',2)
branches={}
for site,base,g in [('B1',100,190),('B2',110,191)]:
 branches[site]=[
  subnet(site,10,base+1,29,'Регистратура '+site,4,'DHCP'),
  subnet(site,20,base+2,28,'Терапия '+site,10,'DHCP'),
  subnet(site,30,base+3,29,'Сестринская '+site,4),
  subnet(site,70,base+4,29,'Печать '+site,2),
  subnet(site,99,base+9,29,'Управление '+site,1),
  subnet(site,90,g,28,'Wi-Fi '+site,10,'DHCP')]
transit=dict(site='C1–C2',vlan='—',octet=250,prefix=30,title='Межэтажный канал',pcs=0,mode='static',infra=2,
 network='10.59.250.0',cidr='10.59.250.0/30',mask='255.255.255.252',broadcast='10.59.250.3',
 first='10.59.250.1',last='10.59.250.2',capacity=2,gateway='—',reserve=0,required=2)
nets.append(transit)
byv={(s['site'],s['vlan']):s for s in nets}
endpoints={}
def endpoint(name,s,offset=None,role=None):
 ip='' if offset is None else str(ipaddress.ip_address(s['network'])+offset)
 endpoints[name]=dict(name=name,site=s['site'],vlan=s['vlan'],subnet=s['cidr'],ip=ip,
  mask=s['mask'],gateway=s['gateway'],dns=DNS if s['site'].startswith('C') else '',
  mode='static' if ip else 'DHCP',department=s['title'],role=role or s['title'])
for start,finish,s,role in [(1,8,REG,'Медицинский регистратор'),(9,16,TER,'Врач-терапевт'),(17,24,DIA,'Врач-диагност')]:
 for i in range(start,finish+1):endpoint(f'C1-PC{i:02}',s,i-start+2 if s['mode']=='static' else None,role)
for start,finish,s,roles in [(1,16,SPEC,None),(17,22,ADM,['Главный врач','Заместитель главного врача','Экономист','Бухгалтер','Специалист по кадрам','Делопроизводитель']),(23,24,IT,['Системный администратор','Инженер ИТ'])]:
 special=['Врач-кардиолог','Врач-невролог','Врач-офтальмолог','Врач-отоларинголог','Врач-хирург','Врач-эндокринолог','Врач-уролог','Врач-дерматолог']
 for i in range(start,finish+1):endpoint(f'C2-PC{i:02}',s,i-start+2 if s['mode']=='static' else None,(roles[i-start] if roles else special[(i-start)//2]))
for site,ss in branches.items():
 for start,end,s,role in [(1,4,ss[0],'Медицинский регистратор'),(5,14,ss[1],'Врач-терапевт'),(15,18,ss[2],'Медицинская сестра')]:
  for i in range(start,end+1):endpoint(f'{site}-PC{i:02}',s,i-start+2 if s['mode']=='static' else None,role)
for site in ['C1','C2','B1','B2']:
 for i in [1,2]:endpoint(f'{site}-PR{i}',byv[site,70],i+1,'Сетевое МФУ')
for name,offset,role in [('SRV-MIS',2,'HTTP: сайт поликлиники и макет МИС'),('SRV-MAIL',3,'DNS, SMTP, POP3'),('SRV-FILE',4,'Файловый архив / макет PACS')]:endpoint(name,SERV,offset,role)
for i,site in enumerate(['C1','C2','B1','B2']):endpoint(f'Tablet PC{i}',byv[site,90],None,'Гостевой планшет')
emails=[]
for s,ids,prefix in [(REG,['C1-PC01','C1-PC02'],'reg'),(TER,['C1-PC09','C1-PC10'],'ther'),(DIA,['C1-PC17','C1-PC18'],'diag'),(SPEC,['C2-PC01','C2-PC02'],'spec'),(ADM,['C2-PC17','C2-PC18'],'admin'),(IT,['C2-PC23','C2-PC24'],'it')]:
 for i,name in enumerate(ids,1):emails.append(dict(device=name,user=prefix+str(i),address=prefix+str(i)+'@clinic8.test',department=s['title']))

# Retain the user's devices and local cabling; remove the three WAN-facing links.
refs={d.findtext('ENGINE/SAVE_REF_ID'):n for n,d in by.items()}
removed=[]
links=root.find('NETWORK/LINKS')
for link in list(links):
 c=link.find('CABLE')
 if c is None:continue
 pair={refs[c.findtext('FROM')],refs[c.findtext('TO')]}
 if pair in [{'R-B1','SW-PROVIDER'},{'R-B2','SW-PROVIDER'},{'R-C1','R-EDGE'}]:
  removed.append(sorted(pair));links.remove(link)
assert len(removed)==3

# IOS router configuration. Router-on-a-stick on each floor/site; only explicit routes.
configs={}
for site in ['C1','C2','B1','B2']:
 name='R-'+site;slist=[s for s in nets if s['site']==site]
 lines=['version 15.1','hostname '+name,'no ip domain-lookup','service dhcp','ip cef']
 for s in slist:
  if s['mode']=='DHCP':
   lines += [f"ip dhcp excluded-address {s['gateway']}",f"ip dhcp pool {site}_V{s['vlan']}",f" network {s['network']} {s['mask']}",f" default-router {s['gateway']}"]
   if site.startswith('C'):lines += [' dns-server '+DNS,' domain-name clinic8.test']
   lines+=[' exit']
 lines+=['interface GigabitEthernet0/0',' no ip address',' no shutdown',' exit']
 for s in slist:
  lines += [f"interface GigabitEthernet0/0.{s['vlan']}",f" encapsulation dot1Q {s['vlan']}",f" ip address {s['gateway']} {s['mask']}", ' exit']
 lines += ['interface GigabitEthernet0/1']
 if site.startswith('C'):
  lines += [f" ip address 10.59.250.{1 if site=='C1' else 2} 255.255.255.252",' no shutdown',' exit']
  for s in nets:
   if s['site']==('C2' if site=='C1' else 'C1'):lines += [f"ip route {s['network']} {s['mask']} 10.59.250.{2 if site=='C1' else 1}"]
 else:lines += [' no ip address',' shutdown',' exit']
 lines+=['interface GigabitEthernet0/2',' no ip address',' shutdown',' exit','interface Vlan1',' no ip address',' shutdown',' exit']
 # Wi-Fi may reach its own gateway; headquarters guests may resolve names and view the site.
 g=byv[site,90]
 lines+=['ip access-list extended WIFI_IN',' permit udp any eq bootpc any eq bootps',f" permit icmp {g['network']} 0.0.0.15 host {g['gateway']}"]
 if site.startswith('C'):
  lines += [f" permit udp {g['network']} 0.0.0.15 host {DNS} eq domain",f" permit tcp {g['network']} 0.0.0.15 host {DNS} eq domain",f" permit tcp {g['network']} 0.0.0.15 host 10.59.20.2 eq www"]
 lines+=[' deny ip any any',' exit','interface GigabitEthernet0/0.90',' ip access-group WIFI_IN in',' exit','end']
 configs[name]=lines

# Access port assignments are taken from the real connections in the input document.
portrows=[]
for link in links:
 c=link.find('CABLE')
 if c is None:continue
 a,b=refs[c.findtext('FROM')],refs[c.findtext('TO')];pa,pb=[n.text for n in c.findall('PORT')]
 if b.startswith('SW-'):a,b,pa,pb=b,a,pb,pa
 if a.startswith('SW-') and a!='SW-PROVIDER':
  if b in endpoints:vid=endpoints[b]['vlan']
  elif '-AP' in b:vid=90
  else:continue
  portrows.append(dict(switch=a,port=pa,endpoint=b,vlan=vid))
assert len(portrows)==99
for name in ['SW-C1A','SW-C1B','SW-C2A','SW-C2B','SW-B1','SW-B2']:
 site=name[3:5];slist=[s for s in nets if s['site']==site];mg=byv[site,99]
 lines=['version 15.0','hostname '+name,'no ip domain-lookup','spanning-tree mode pvst']
 for s in slist:lines += [f"vlan {s['vlan']}",f" name {site}_V{s['vlan']}",' exit']
 for row in portrows:
  if row['switch']==name:
   lines += [f"interface {row['port']}",f" description {row['endpoint']}",' switchport mode access',f" switchport access vlan {row['vlan']}",' spanning-tree portfast',' no shutdown',' exit']
 used={p['port'] for p in portrows if p['switch']==name}
 for i in range(1,25):
  if 'FastEthernet0/'+str(i) not in used:lines+=['interface FastEthernet0/'+str(i),' shutdown',' exit']
 trunkports=['GigabitEthernet0/1']+(['GigabitEthernet0/2'] if name in ['SW-C1A','SW-C2A'] else [])
 for p in trunkports:
  lines+=['interface '+p,' switchport mode trunk',' switchport trunk allowed vlan '+','.join(str(s['vlan']) for s in slist),' no shutdown',' exit']
 if 'GigabitEthernet0/2' not in trunkports:lines+=['interface GigabitEthernet0/2',' shutdown',' exit']
 offset=3 if name.endswith('B') else 2
 mgip=str(ipaddress.ip_address(mg['network'])+offset)
 lines+=['interface Vlan1',' no ip address',' shutdown',' exit','interface Vlan99',f" ip address {mgip} {mg['mask']}",' no shutdown',' exit','ip default-gateway '+mg['gateway'],'end']
 configs[name]=lines
 endpoints[name]=dict(name=name,site=site,vlan=99,subnet=mg['cidr'],ip=mgip,mask=mg['mask'],gateway=mg['gateway'],dns='',mode='static',department=mg['title'],role='Коммутатор доступа')

for name,lines in configs.items():
 eng=by[name].find('ENGINE')
 for tag in ['RUNNINGCONFIG','STARTUPCONFIG']:
  cfg=eng.find(tag);clear(cfg)
  for line in lines:E.SubElement(cfg,'LINE').text=line
 if name.startswith('SW-'):
  vl=eng.find('VLANS');clear(vl)
  for vid,vname in [(1,'default'),(1002,'fddi-default'),(1003,'token-ring-default'),(1004,'fddinet-default'),(1005,'trnet-default')]+[(s['vlan'],f"{s['site']}_V{s['vlan']}") for s in nets if s['site']==name[3:5]]:
   E.SubElement(vl,'VLAN',number=str(vid),name=vname,rspan='0')
 # Save CLI replay with configuration-mode wrappers and explicit persistence.
 (SUP/'configs'/f'{name}.txt').write_text('enable\nconfigure terminal\n'+'\n'.join(l for l in lines if not l.startswith('version '))+'\nwrite memory\n')

for name,ep in endpoints.items():
 if name.startswith('SW-'):continue
 eng=by[name].find('ENGINE');typ='eHostWirelessN' if name.startswith('Tablet') else 'eCopperFastEthernet'
 p=next(p for p in eng.findall('.//PORT') if p.findtext('TYPE')==typ)
 for tag,val in [('IP',ep['ip']),('SUBNET',ep['mask'] if ep['ip'] else ''),('PORT_GATEWAY',ep['gateway'] if ep['ip'] else ''),('PORT_DNS',ep['dns'] if ep['ip'] else ''),('PORT_DHCP_ENABLE','true' if ep['mode']=='DHCP' else 'false')]:put(p,tag,val)
 put(eng,'GATEWAY',ep['gateway'] if ep['ip'] else '')
 put(eng.find('DNS_CLIENT'),'SERVER_IP',ep['dns'] if ep['ip'] else '')
 dm=eng.find('DHCP_CLIENT/PORT_DATA_MAP');clear(dm)
 if ep['mode']=='DHCP':put(E.SubElement(dm,'PORT_DATA_ENTRY'),'PORT','Wireless0' if name.startswith('Tablet') else 'FastEthernet0')

# Exact wireless settings copied from the historical, user-saved 8.2.2 schema,
# then assigned new unique SSIDs and the same educational WPA2/AES key.
for i,site in enumerate(['C1','C2','B1','B2']):
 ap=by[site+'-AP1'].find('ENGINE/WIRELESS_SERVER/WIRELESS_COMMON')
 source=oldby[site+'-AP1'].find('ENGINE/WIRELESS_SERVER/WIRELESS_COMMON')
 ap.getparent().replace(ap,copy.deepcopy(source));ap=by[site+'-AP1'].find('ENGINE/WIRELESS_SERVER/WIRELESS_COMMON')
 ssid='Clinic8-'+site+'-Guest';put(ap,'SSID',ssid)
 tab=by['Tablet PC'+str(i)].find('ENGINE/WIRELESS_CLIENT')
 saved=oldby['Tablet PC'+str(i)].find('ENGINE/WIRELESS_CLIENT')
 tab.getparent().replace(tab,copy.deepcopy(saved));tab=by['Tablet PC'+str(i)].find('ENGINE/WIRELESS_CLIENT')
 wc=tab.find('WIRELESS_COMMON')
 for t,v in [('SSID',ssid),('AUTHEN_TYPE',4),('ENCRYPT_TYPE',4)]:put(wc,t,v)
 wp=wc.find('WEP_PROCESS')
 if wp is None:wp=E.SubElement(wc,'WEP_PROCESS')
 for t,v in [('KEY',PASS),('USERID',''),('PASSWORD',''),('ENCRYPTION',4)]:put(wp,t,v)
 for profile in tab.findall('.//WIRELESS_PROFILE'):
  for t,v in [('NAME',ssid),('SSID',ssid),('AUTHEN_TYPE',4),('ENCRYPT_TYPE',4),('WEP_KEY',PASS),('DHCP_ENABLED',1),('IP_ADDRESS',''),('SUBNET_MASK',''),('DEFAULT_GATEWAY',''),('DNS','')]:put(profile,t,v)

# DNS and mail, with two clients in each of the six headquarters departments.
eng=by['SRV-MAIL'].find('ENGINE');dns=eng.find('DNS_SERVER');put(dns,'ENABLED',1)
db=dns.find('NAMESERVER-DATABASE');clear(db)
records={'clinic8.test':'10.59.20.2','www.clinic8.test':'10.59.20.2','mis.clinic8.test':'10.59.20.2','mail.clinic8.test':DNS,'files.clinic8.test':'10.59.20.4'}
for host,ip in records.items():
 rr=E.SubElement(db,'RESOURCE-RECORD')
 for t,v in [('TYPE','A-REC'),('NAME',host),('TTL',86400),('IPADDRESS',ip)]:put(rr,t,v)
mail=eng.find('EMAIL_SERVER');clear(mail)
for t,v in [('SMTP_ENABLED',1),('SMTP_DOMAIN','clinic8.test'),('POP3_ENABLED',1),('FORWARD_MAIL',0),('NO_OF_USERS',12)]:put(mail,t,v)
for i,e in enumerate(emails):
 for t,v in [('USER',e['user']),('PASSWORD',PASS),('NO_OF_MAILS',0)]:put(mail,t+str(i),v)
 cl=by[e['device']].find('ENGINE/EMAIL_CLIENT')
 for t,v in [('ENABLED',1),('NAME',endpoints[e['device']]['role']),('MAIL_ID',e['address']),('POP3_SERVER','mail.clinic8.test'),('SMTP_SERVER','mail.clinic8.test'),('USER',e['user']),('PASSWORD',PASS),('NO_OF_MAILS',0)]:put(cl,t,v)

html='''<html><head><meta charset="utf-8"><title>Городская поликлиника № 8</title></head>
<body bgcolor="#edf5f7"><center><table width="760" cellpadding="20" bgcolor="white"><tr><td>
<font color="#126c78" size="6"><b>Городская поликлиника № 8</b></font><hr>
<h2>Здоровье рядом с вами</h2><p>Центральный корпус и два районных филиала. Доступная помощь для всей семьи.</p>
<h3>Отделения</h3><p>Регистратура • Терапия • Диагностика • Врачи-специалисты</p>
<h3>Время работы</h3><p>Понедельник–пятница: 08:00–20:00. Суббота: 09:00–15:00.</p>
<h3>Запись на приём</h3><p>Обратитесь в регистратуру. Подготовьте документ, удостоверяющий личность, и полис ОМС.</p>
<h3>Единый диагностический архив</h3><p>Проект предусматривает общую медицинскую историю и обмен исследованиями. В ДЗ2 филиалы работают автономно.</p>
<hr><p>Учебный сайт • Устинов Илья Максимович • ИУ10-59 • Вариант 8</p>
<p>Демонстрационный макет: запись пациентов и обработка медицинских данных не выполняются.</p>
</td></tr></table></center></body></html>'''
(SUP/'index.html').write_text(html)
for name,page in [('SRV-MIS',html),('SRV-FILE','<html><body><h1>Поликлиника № 8 — диагностический архив</h1><p>Учебный макет файлового архива и PACS. Медицинские данные отсутствуют.</p></body></html>')]:
 eng=by[name].find('ENGINE');put(eng.find('HTTP_SERVER'),'ENABLED',1)
 for f in eng.findall('.//FILE'):
  if f.findtext('NAME') in ['http:','index.html'] and f.find('FILE_CONTENT/TEXT') is not None:put(f.find('FILE_CONTENT'),'TEXT',page)
# Disable unrelated default server services, retain FTP only for the archive.
for name in ['SRV-MIS','SRV-MAIL','SRV-FILE']:
 eng=by[name].find('ENGINE')
 if name!='SRV-MAIL':
  for tag in ['SMTP_ENABLED','POP3_ENABLED']:put(eng.find('EMAIL_SERVER'),tag,0)
 if name=='SRV-MAIL':put(eng.find('HTTP_SERVER'),'ENABLED',0)
 if eng.find('HTTPS_SERVER/ENABLED') is not None:put(eng.find('HTTPS_SERVER'),'ENABLED',0)
for name in ['R-EDGE','R-ISP','SW-PROVIDER','PUBLIC-WEB']:put(by[name].find('ENGINE'),'POWER','false')

# A readable enlarged logical layout, including role labels and every static host IP.
notes=root.find('PHYSICALWORKSPACE/NOTES');clear(notes)
rects=root.find('RECTANGLES');clear(rects)
def note(x,y,text):
 i=len(notes);n=E.SubElement(notes,'NOTE',uuid='{'+str(uuid.uuid5(uuid.NAMESPACE_DNS,'hw2-note-'+str(i)))+'}')
 for t,v in [('X',x),('Y',y),('Z',40000+i),('TEXT',text),('NOTECLUSTERID','1-1'),('MEM_ADDR',920000000+i)]:put(n,t,v)
def pos(name,x,y,label=None):
 p=by[name].find('WORKSPACE/LOGICAL');put(p,'X',x);put(p,'Y',y)
 if label:note(x-45,y+40,label)
colors={'C1':(225,239,255),'C2':(225,245,237),'B1':(255,243,221),'B2':(242,231,253)}
for site,x,y in [('C1',40,100),('C2',40,1550),('B1',1800,100),('B2',1800,1550)]:
 r=E.SubElement(rects,'RECTANGLE',uuid='{'+str(uuid.uuid5(uuid.NAMESPACE_DNS,'hw2-'+site))+'}')
 for t,v in [('TopLeftX',x),('TopLeftY',y),('BottomRightX',x+1650),('BottomRightY',y+1400)]:put(r,t,v)
 c=E.SubElement(r,'Color')
 for t,v in zip(['Red','Green','Blue'],colors[site]):put(c,t,v)
 E.SubElement(r,'Filled',OUTLINECOLOR='#176dea',OUTLINED='true').text='1'
 put(r,'RECTCLUSTERID','1-1');put(r,'MEM_ADDR',910000000+len(rects))
 note(x+20,y+15,{'C1':'ЦЕНТРАЛЬНЫЙ КОРПУС — ЭТАЖ 1','C2':'ЦЕНТРАЛЬНЫЙ КОРПУС — ЭТАЖ 2','B1':'ФИЛИАЛ 1 — АВТОНОМНЫЙ','B2':'ФИЛИАЛ 2 — АВТОНОМНЫЙ'}[site])
 pos('R-'+site,x+760,y+110,'Шлюзы VLAN / DHCP-сервер IOS'+ ('\nGi0/1: 10.59.250.'+('1' if site=='C1' else '2')+'/30' if site.startswith('C') else '\nСвязь с центром отсутствует'))
 sws=['SW-'+site+'A','SW-'+site+'B'] if site.startswith('C') else ['SW-'+site]
 for i,n in enumerate(sws):pos(n,x+430+650*i,y+250,'Управление: '+endpoints[n]['ip']+'/29')
 count=24 if site.startswith('C') else 18
 for i in range(1,count+1):
  name=f'{site}-PC{i:02}';ep=endpoints[name]
  label=ep['department']+'\n'+ep['role']+'\n'+(ep['ip']+'/'+ep['subnet'].split('/')[1] if ep['ip'] else 'DHCP • VLAN '+str(ep['vlan']))
  pos(name,x+95+265*((i-1)%6),y+420+190*((i-1)//6),label)
 for i in [1,2]:
  name=f'{site}-PR{i}';pos(name,x+95+(i-1)*265,y+1200,'МФУ • '+endpoints[name]['ip']+'/29')
 pos(site+'-AP1',x+625,y+1200,'Wi-Fi: Clinic8-'+site+'-Guest\nWPA2-PSK / AES • VLAN 90')
 tab='Tablet PC'+str(['C1','C2','B1','B2'].index(site));pos(tab,x+725,y+1250,'Гостевой планшет • DHCP')
 if site=='C1':
  for i,n in enumerate(['SRV-MIS','SRV-MAIL','SRV-FILE']):pos(n,x+1050+200*i,y+1200,endpoints[n]['ip']+'/29\n'+{'SRV-MIS':'HTTP: сайт / макет МИС','SRV-MAIL':'DNS, SMTP, POP3','SRV-FILE':'Файловый архив\nМакет PACS'}[n])
for i,n in enumerate(['R-EDGE','SW-PROVIDER','R-ISP','PUBLIC-WEB']):pos(n,700+550*i,3180,'Оборудование ДЗ1\nвыключено, вне ДЗ2')
note(40,30,'ДЗ2 • Вариант 8 • Группа ИУ10-59 • 10.59.0.0/16 • Администрация 10.59.8.0/28 • Межплощадочные связи отсутствуют')
note(40,3080,'ОПЕРАТОРСКИЙ СЕГМЕНТ ДЗ1 СОХРАНЁН КАК ВЫКЛЮЧЕННЫЙ РЕЗЕРВ. К СЕТЯМ ПОЛИКЛИНИКИ НЕ ПОДКЛЮЧЁН.')

# Preserve original document bytes everywhere except the explicitly changed blocks.
outxml=xml
for start,end,element in [(b'<DEVICES>',b'</DEVICES>',root.find('NETWORK/DEVICES')),(b'<LINKS>',b'</LINKS>',root.find('NETWORK/LINKS')),(b'<RECTANGLES>',b'</RECTANGLES>',root.find('RECTANGLES'))]:
 a=outxml.index(start);b=outxml.index(end,a)+len(end);outxml=outxml[:a]+E.tostring(element,encoding='utf-8',with_tail=False)+outxml[b:]
a=outxml.index(b'<PHYSICALWORKSPACE>');b=outxml.index(b'</PHYSICALWORKSPACE>',a)
part=outxml[a:b];part=re.sub(rb'<NOTES>.*?</NOTES>',E.tostring(notes,encoding='utf-8',with_tail=False),part,count=1,flags=re.S)
outxml=outxml[:a]+part+outxml[b:]
packed=encode_document(outxml)
pkt=OUT/'Устинов ИУ10-59 ДЗ2 — для проверки.pkt';pkt.write_bytes(packed)
(W/'hw2.xml').write_bytes(outxml)
data=dict(nets=nets,endpoints=endpoints,emails=emails,dns=records,removed_links=removed,password=PASS,source_version=root.findtext('VERSION'),source_sha256=hashlib.sha256(raw).hexdigest(),output_sha256=hashlib.sha256(packed).hexdigest())
(SUP/'project.json').write_text(json.dumps(data,ensure_ascii=False,indent=2))
for name,rows in [('subnets',nets),('endpoints',list(endpoints.values())),('ports',portrows),('email',emails)]:
 with (SUP/(name+'.csv')).open('w',newline='',encoding='utf-8-sig') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
print('Built',pkt,'with',len(nets),'subnets;',len(endpoints),'addressed hosts;',len(emails),'mail users;',len(links),'links')
