from pathlib import Path
import sys,json,ipaddress,re,collections,hashlib,math
from lxml import etree as E
sys.path.insert(0,'/workspace/work/repo/tools')
from pkt_document_codec import decode_document,encode_document
W=Path('/workspace/work');D=json.loads((W/'hw2_support/project.json').read_text())
f=next((W/'deliverables').glob('*.pkt'));raw=f.read_bytes();xml=decode_document(raw);r=E.fromstring(xml)
src=E.fromstring((W/'source.xml').read_bytes());dev=r.findall('NETWORK/DEVICES/DEVICE')
by={d.findtext('ENGINE/NAME'):d for d in dev};ref={d.findtext('ENGINE/SAVE_REF_ID'):n for n,d in by.items()}
assert len(by)==len(dev)==120
assert set(by)=={d.findtext('ENGINE/NAME') for d in src.findall('NETWORK/DEVICES/DEVICE')}
assert r.findtext('VERSION')=='8.2.2.0400'
assert encode_document(xml)==raw
assert hashlib.sha256((W/'hw1/Устинов ИУ10-59.pkt').read_bytes()).hexdigest()==D['source_sha256']
checks=['Контейнер PKT: EAX, zlib и побайтовое повторное кодирование','Исходный PKT не изменён; версия 8.2.2.0400 сохранена','Сохранены все 120 устройств исходника']
nets=[ipaddress.ip_network(n['cidr']) for n in D['nets']]
assert all(not a.overlaps(b) for i,a in enumerate(nets) for b in nets[i+1:])
assert all(n.subnet_of(ipaddress.ip_network('10.59.0.0/16')) for n in nets)
assert next(n for n in D['nets'] if n['title']=='Администрация')['cidr']=='10.59.8.0/28'
for n in D['nets']:
 assert n['capacity']>=n['required']
 assert ipaddress.ip_network(n['cidr']).num_addresses-2==n['capacity']
checks+=['26 подсетей без пересечений, внутри 10.59.0.0/16','Администрация: VLAN 8, 10.59.8.0/28','Проверены маски, диапазоны, broadcast и вместимость с резервом']
configs={n:[(l.text or "").rstrip() for l in d.findall('ENGINE/RUNNINGCONFIG/LINE')] for n,d in by.items() if d.find('ENGINE/RUNNINGCONFIG') is not None}
assert not any(re.match(r'\s*ip route 0\.0\.0\.0\s+0\.0\.0\.0',l) for cfg in configs.values() for l in cfg)
assert not any('default-information originate' in l for cfg in configs.values() for l in cfg)
for name in ['R-C1','R-C2']:
 other='C2' if name=='R-C1' else 'C1';nh='10.59.250.'+('2' if name=='R-C1' else '1')
 expected={f"ip route {n['network']} {n['mask']} {nh}" for n in D['nets'] if n['site']==other}
 assert expected=={l for l in configs[name] if l.startswith('ip route ')}
for name in ['R-B1','R-B2']:assert not any(l.startswith('ip route ') for l in configs[name])
checks+=['Нет нулевых маршрутов; проверены все 13 явных межэтажных маршрутов','Маршрутизация филиалов — только между собственными VLAN']
graph=collections.defaultdict(set);used=set();portmap={}
for l in r.findall('NETWORK/LINKS/LINK'):
 c=l.find('CABLE');a,b=ref[c.findtext('FROM')],ref[c.findtext('TO')];pa,pb=[x.text for x in c.findall('PORT')]
 for n,p in [(a,pa),(b,pb)]:assert (n,p) not in used;used.add((n,p))
 graph[a].add(b);graph[b].add(a);portmap[a,b]=(pa,pb);portmap[b,a]=(pb,pa)
def reachable(start):
 seen={start};q=[start]
 while q:
  for n in graph[q.pop()]:
   if n not in seen:seen.add(n);q.append(n)
 return seen
main=reachable('R-C1');b1=reachable('R-B1');b2=reachable('R-B2')
assert 'R-C2' in main and not main&b1 and not main&b2 and not b1&b2
assert len(r.findall('NETWORK/LINKS/LINK'))==109
assert not main&{'R-EDGE','R-ISP','SW-PROVIDER','PUBLIC-WEB'}
checks+=['109 кабелей, уникальные порты и корректные ссылки','Физически независимы центр, филиал 1, филиал 2 и резерв оператора']
def sections(lines):
 out={};cur=None
 for l in lines:
  if l.startswith('interface '):cur=l.split(' ',1)[1];out.setdefault(cur,[])
  elif l.strip()=='exit':cur=None
  elif cur:out[cur].append(l.strip())
 return out
addresses=[];dhcp=static=0
for name,e in D['endpoints'].items():
 if e['ip']:
  a=ipaddress.ip_address(e['ip']);n=ipaddress.ip_network(e['subnet'])
  assert a in n and a not in [n.network_address,n.broadcast_address,ipaddress.ip_address(e['gateway'])]
  addresses.append(e['ip']);static+=1
 else:dhcp+=1
 if not name.startswith('SW-'):
  ps=[p for p in by[name].findall('ENGINE/.//PORT') if p.findtext('TYPE')==('eHostWirelessN' if name.startswith('Tablet') else 'eCopperFastEthernet')]
  assert len(ps)==1
  p=ps[0];assert (p.findtext('IP') or '')==e['ip']
  assert p.findtext('PORT_DHCP_ENABLE')==('true' if e['mode']=='DHCP' else 'false')
  if e['ip']:assert p.findtext('SUBNET')==e['mask'] and p.findtext('PORT_GATEWAY')==e['gateway']
  elif not name.startswith('Tablet'):
   ss=sections(configs['R-'+e['site']]); assert f"ip address {e['gateway']} {e['mask']}" in ss[f"GigabitEthernet0/0.{e['vlan']}"]
 if name.startswith('Tablet'):continue
 if not name.startswith('SW-'):
  sw=next(n for n in graph[name] if n.startswith('SW-'));p=portmap[sw,name][0]
  assert f"switchport access vlan {e['vlan']}" in sections(configs[sw])[p]
assert len(addresses)==len(set(addresses))
for name in configs:
 if name.startswith('SW-') and name!='SW-PROVIDER':
  vlan_ids={int(x.attrib['number']) for x in by[name].findall('ENGINE/VLANS/VLAN')}
  expected={n['vlan'] for n in D['nets'] if n['site']==name[3:5]}
  assert expected<=vlan_ids
  for port,lines in sections(configs[name]).items():
   if 'switchport mode trunk' in lines:
    allowed=next(l.split('vlan ')[1] for l in lines if l.startswith('switchport trunk allowed vlan '))
    assert expected==set(map(int,allowed.split(',')))
checks+=['Все 84 ПК и инфраструктура сопоставлены с VLAN, адресами и шлюзами','Нет конфликтов статических IP; адреса DHCP не пересекаются со статикой','Согласованы access-порты, trunk allowed VLAN и отдельные базы VLAN Cisco']
for site in ['C1','C2','B1','B2']:
 a=by[site+'-AP1'].find('ENGINE/WIRELESS_SERVER/WIRELESS_COMMON')
 t=by['Tablet PC'+str(['C1','C2','B1','B2'].index(site))].find('ENGINE/WIRELESS_CLIENT/WIRELESS_COMMON')
 assert a.findtext('SSID')==t.findtext('SSID')=='Clinic8-'+site+'-Guest'
 assert a.findtext('AUTHEN_TYPE')==t.findtext('AUTHEN_TYPE')=='4'
 assert a.findtext('ENCRYPT_TYPE')==t.findtext('ENCRYPT_TYPE')=='4'
 assert a.findtext('WEP_PROCESS/KEY')==t.findtext('WEP_PROCESS/KEY')==D['password']
 apdev=by[site+'-AP1'];tdev=by['Tablet PC'+str(['C1','C2','B1','B2'].index(site))]
 ax,ay=[float(apdev.findtext('WORKSPACE/LOGICAL/'+v)) for v in ['X','Y']]
 tx,ty=[float(tdev.findtext('WORKSPACE/LOGICAL/'+v)) for v in ['X','Y']]
 radius=float(next(p.findtext('COVERAGERANGE') for p in apdev.findall('ENGINE/.//PORT') if p.findtext('TYPE')=='eAccessPointWirelessG'))
 assert math.hypot(ax-tx,ay-ty)<radius
checks+=['Четыре пары AP/планшет: совпадают SSID и параметры WPA2/AES; планшеты DHCP']
m=by['SRV-MAIL'].find('ENGINE/EMAIL_SERVER');assert m.findtext('NO_OF_USERS')=='12'
assert set(m.findtext('USER'+str(i)) for i in range(12))=={e['user'] for e in D['emails']}
assert set(collections.Counter(e['department'] for e in D['emails']).values())=={2}
for e in D['emails']:
 cl=by[e['device']].find('ENGINE/EMAIL_CLIENT');assert cl.findtext('MAIL_ID')==e['address'] and cl.findtext('USER')==e['user']
rr={x.findtext('NAME'):x.findtext('IPADDRESS') for x in by['SRV-MAIL'].findall('ENGINE/DNS_SERVER/NAMESERVER-DATABASE/RESOURCE-RECORD')}
assert rr==D['dns']
assert by['SRV-MIS'].findtext('ENGINE/HTTP_SERVER/ENABLED')=='1'
assert any('Городская поликлиника № 8' in (t.text or '') for t in by['SRV-MIS'].findall('.//FILE_CONTENT/TEXT'))
checks+=['12 почтовых клиентов: по два сотрудника шести отделов; учётные записи согласованы','DNS содержит пять A-записей; HTTP включён и тематическая страница сохранена']
print('PASS',len(checks),'structural groups; DHCP',dhcp,'static',static)
